var mongoose = require('mongoose')
	, ObjectId = mongoose.Schema.ObjectId;

var QuoteSchema = new mongoose.Schema({
	name: String,
	quote: String,
	likes: Number,	
}, {timestamps: true})

mongoose.model('Quote', QuoteSchema);
var Quote = mongoose.model('Quote')