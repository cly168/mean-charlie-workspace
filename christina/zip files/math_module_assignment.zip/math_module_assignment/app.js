var math = require('./mathlib');
console.log(math);
console.log(math.add(1,2));
math.multiply(1,2);
math.square(2);
console.log(math.random(2,4));