app.controller('regController', ['$scope', 'usersFactory', '$location', function($scope, usersFactory, $location){
	$scope.users=[];
	$scope.user={};
	$scope.message = '';
	function success(users){
		$scope.users = users;
		$scope.user = {};
		$location.url('/success');
	}

	//-err is user_json.data so err.message is message-//
	function error(err){
		if(err.errors.password){
			$scope.message = err.errors.password.message;
		}
		else if(err.errors.first_name){
			$scope.message = err.errors.first_name.message;
		}
		else if(err.errors.last_name){
			$scope.message = err.errors.last_name.message;
		}
		else if(err.errors.bday){
			$scope.message = err.errors.bday.message;
		}
		else{
			$scope.message = err.message;
		}
	}
	$scope.regUser = function(){
		if($scope.user.password != $scope.user.password_confirm){
			$scope.message = 'password and password confirm must match';
		}
		else{
			$scope.message = '';
			usersFactory.regUsers($scope.user, success, error)
		}
		
	}
}])