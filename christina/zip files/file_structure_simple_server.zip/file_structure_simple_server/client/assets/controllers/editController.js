app.controller('editController', ['$scope', function($scope){
	$scope.update = function(id){
		console.log('Edit Friend clicked!')
	}
}])